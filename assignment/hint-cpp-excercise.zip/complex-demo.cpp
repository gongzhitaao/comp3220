#include <iostream>
using namespace std;

#include "complex.h"

int main() {
  using namespace ppl;

  Complex a{1, 2};
  Complex b;
  Complex c{1.0};
}
